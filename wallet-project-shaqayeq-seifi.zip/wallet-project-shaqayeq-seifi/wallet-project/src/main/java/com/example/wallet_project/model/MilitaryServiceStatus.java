package com.example.wallet_project.model;

public enum MilitaryServiceStatus {
	
    EXEMPTED,
    COMPLETED,
    POSTPONED,
    IN_SERVICE,
    NOT_APPLICABLE
  
}
