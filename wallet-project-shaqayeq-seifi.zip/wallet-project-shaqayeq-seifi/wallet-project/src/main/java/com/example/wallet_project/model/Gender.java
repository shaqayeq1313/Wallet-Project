package com.example.wallet_project.model;

public enum Gender {
	
	    MALE,
	    FEMALE,
	    OTHER

}
